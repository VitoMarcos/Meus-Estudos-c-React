import React, { useEffect, useState } from 'react';
import { Carro } from '../interfaces/carro';

const ListaCarros: React.FC = () => {
    const [carros, setCarros] = useState<Carro[]>([]);

    useEffect(() => {
        fetch('http://localhost:5133/Carro/Listar') 
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erro na requisição: ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                setCarros(data);
            })
            .catch(error => {
                console.error('Erro:', error);
            });
    }, []); 

    const Deletar = (id: string) => {
        fetch(`http://localhost:5133/Carro/Deletar/${id}`, { 
            method: 'DELETE',
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na requisição: ' + response.statusText);
            }
            // Atualize a lista de carros após a exclusão
            setCarros(carros.filter(carro => carro.id !== id));
        })
        .catch(error => {
            console.error('Erro:', error);
        });
    };

    // Função para formatar a data corretamente
    const formatDate = (dateString: string) => {
        const date = new Date(dateString);
        // Verifica se a data é válida
        if (isNaN(date.getTime())) {
            return "Data inválida";
        }
        return date.toLocaleDateString(); // Formato de data padrão
    };

    return (
        <div>
            <h1>Lista de Carros</h1>
            <table border={1}>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Ano</th>
                        <th>Criado Em</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    {carros.map(carro => (
                        <tr key={carro.id}>
                            <td>{carro.id}</td>
                            <td>{carro.marca}</td>
                            <td>{carro.modelo}</td>
                            <td>{carro.ano}</td>
                            <td>{formatDate(carro.criadoEm)}</td> {}
                            <td>
                                <button onClick={() => Deletar(carro.id)}>Deletar</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ListaCarros;

import React, { useState } from 'react';
import { Carro } from '../interfaces/carro';

const CadastroCarro: React.FC = () => {
    const [marca, setMarca] = useState<string>('');
    const [modelo, setModelo] = useState<string>('');
    const [ano, setAno] = useState<number>(new Date().getFullYear());

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        const novoCarro: Omit<Carro, 'id' | 'criadoEm'> = {
            marca,
            modelo,
            ano,
        };

        fetch('http://localhost:5133/Carro/Cadastrar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(novoCarro)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na requisição: ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            setMarca('');
            setModelo('');
            setAno(new Date().getFullYear());
        })
        .catch(error => {
            console.error('Erro:', error);
        });
    };

    return (
        <div>
            <h2>Cadastrar Novo Carro</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Marca:
                    <input type="text" value={marca} onChange={e => setMarca(e.target.value)} required />
                </label>
                <label>
                    Modelo:
                    <input type="text" value={modelo} onChange={e => setModelo(e.target.value)} required />
                </label>
                <label>
                    Ano:
                    <input type="number" value={ano} onChange={e => setAno(Number(e.target.value))} required />
                </label>
                <button type="submit">Cadastrar</button>
            </form>
        </div>
    );
};

export default CadastroCarro;

import './App.css';
import { BrowserRouter, Route, Routes, Link } from 'react-router-dom';
import ListaCarros from './components/ListaCarros';
import CadastroCarro from './components/CadastroCarro';

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <div className="App">
      <nav>
                    <ul>
                        <li>
                            <Link to="/">Carros</Link>
                        </li>
                        <li>
                            <Link to="/cadastro">Cadastrar carros</Link>
                        </li>
                    </ul>
                </nav>
                <Routes>
                    <Route path="/" element={<ListaCarros />} />
                    <Route path="/cadastro" element={<CadastroCarro />} />
                </Routes>
      </div>
      </BrowserRouter>
  );
};

export default App;

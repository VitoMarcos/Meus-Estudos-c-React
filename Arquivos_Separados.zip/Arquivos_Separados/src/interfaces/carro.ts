export interface Carro {
    id: string;
    marca: string;
    modelo: string;
    ano: number;
    criadoEm: string;
}
